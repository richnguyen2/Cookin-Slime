The program is a game called, Cookin Slime, where the player plays as a slime and
to fullfill orders given at the top. You can pick up and place down ingredients, chop meat,
cook meat, and burn meat as well. After creating the order, it should be placed to the table
on the right.
The controls to move are the arrow keys.
The key to pick up/place down items is Z (A for gba).
The key X (B for gba) can be used to cut meat if the meat is put on the cutting board, and
it can also cook the meat if the meat is put on the stove.
