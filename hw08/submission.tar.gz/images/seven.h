/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 seven seven.png 
 * Time-stamp: Sunday 07/16/2023, 21:37:28
 * 
 * Image Information
 * -----------------
 * seven.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SEVEN_H
#define SEVEN_H

extern const unsigned short seven[35];
#define SEVEN_SIZE 70
#define SEVEN_LENGTH 35
#define SEVEN_WIDTH 5
#define SEVEN_HEIGHT 7

#endif

