/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 four four.png 
 * Time-stamp: Sunday 07/16/2023, 21:10:35
 * 
 * Image Information
 * -----------------
 * four.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FOUR_H
#define FOUR_H

extern const unsigned short four[35];
#define FOUR_SIZE 70
#define FOUR_LENGTH 35
#define FOUR_WIDTH 5
#define FOUR_HEIGHT 7

#endif

