/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 broke broke.png 
 * Time-stamp: Monday 07/17/2023, 07:03:24
 * 
 * Image Information
 * -----------------
 * broke.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BROKE_H
#define BROKE_H

extern const unsigned short broke[38400];
#define BROKE_SIZE 76800
#define BROKE_LENGTH 38400
#define BROKE_WIDTH 240
#define BROKE_HEIGHT 160

#endif

