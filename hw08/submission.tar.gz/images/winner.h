/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 winner winner.png 
 * Time-stamp: Monday 07/17/2023, 17:14:25
 * 
 * Image Information
 * -----------------
 * winner.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINNER_H
#define WINNER_H

extern const unsigned short winner[38400];
#define WINNER_SIZE 76800
#define WINNER_LENGTH 38400
#define WINNER_WIDTH 240
#define WINNER_HEIGHT 160

#endif

