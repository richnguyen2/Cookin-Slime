/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x7 buns buns.png 
 * Time-stamp: Friday 07/14/2023, 16:38:24
 * 
 * Image Information
 * -----------------
 * buns.png 20@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BUNS_H
#define BUNS_H

extern const unsigned short buns[140];
#define BUNS_SIZE 280
#define BUNS_LENGTH 140
#define BUNS_WIDTH 20
#define BUNS_HEIGHT 7

#endif

