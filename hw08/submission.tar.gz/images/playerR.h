/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 playerR playerR.png 
 * Time-stamp: Friday 07/14/2023, 01:36:37
 * 
 * Image Information
 * -----------------
 * playerR.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYERR_H
#define PLAYERR_H

extern const unsigned short playerR[400];
#define PLAYERR_SIZE 800
#define PLAYERR_LENGTH 400
#define PLAYERR_WIDTH 20
#define PLAYERR_HEIGHT 20

#endif

