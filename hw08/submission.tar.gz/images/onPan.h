/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x13 onPan onPan.png 
 * Time-stamp: Saturday 07/15/2023, 23:43:20
 * 
 * Image Information
 * -----------------
 * onPan.png 20@13
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ONPAN_H
#define ONPAN_H

extern const unsigned short onPan[260];
#define ONPAN_SIZE 520
#define ONPAN_LENGTH 260
#define ONPAN_WIDTH 20
#define ONPAN_HEIGHT 13

#endif

