/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x7 choppedPatty choppedPatty.png 
 * Time-stamp: Sunday 07/16/2023, 06:27:50
 * 
 * Image Information
 * -----------------
 * choppedPatty.png 20@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHOPPEDPATTY_H
#define CHOPPEDPATTY_H

extern const unsigned short choppedPatty[140];
#define CHOPPEDPATTY_SIZE 280
#define CHOPPEDPATTY_LENGTH 140
#define CHOPPEDPATTY_WIDTH 20
#define CHOPPEDPATTY_HEIGHT 7

#endif

