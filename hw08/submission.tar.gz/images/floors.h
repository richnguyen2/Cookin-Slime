/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 floors floors.png 
 * Time-stamp: Sunday 07/16/2023, 06:22:31
 * 
 * Image Information
 * -----------------
 * floors.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLOORS_H
#define FLOORS_H

extern const unsigned short floors[38400];
#define FLOORS_SIZE 76800
#define FLOORS_LENGTH 38400
#define FLOORS_WIDTH 240
#define FLOORS_HEIGHT 160

#endif

