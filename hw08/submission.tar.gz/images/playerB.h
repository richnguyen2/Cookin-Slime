/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 playerB playerB.png 
 * Time-stamp: Friday 07/14/2023, 02:05:14
 * 
 * Image Information
 * -----------------
 * playerB.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYERB_H
#define PLAYERB_H

extern const unsigned short playerB[400];
#define PLAYERB_SIZE 800
#define PLAYERB_LENGTH 400
#define PLAYERB_WIDTH 20
#define PLAYERB_HEIGHT 20

#endif

