/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x13 pattyFinished pattyFinished.png 
 * Time-stamp: Saturday 07/15/2023, 23:58:24
 * 
 * Image Information
 * -----------------
 * pattyFinished.png 20@13
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PATTYFINISHED_H
#define PATTYFINISHED_H

extern const unsigned short pattyFinished[260];
#define PATTYFINISHED_SIZE 520
#define PATTYFINISHED_LENGTH 260
#define PATTYFINISHED_WIDTH 20
#define PATTYFINISHED_HEIGHT 13

#endif

