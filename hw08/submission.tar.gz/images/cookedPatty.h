/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x7 cookedPatty cookedPatty.png 
 * Time-stamp: Sunday 07/16/2023, 01:28:17
 * 
 * Image Information
 * -----------------
 * cookedPatty.png 20@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef COOKEDPATTY_H
#define COOKEDPATTY_H

extern const unsigned short cookedPatty[140];
#define COOKEDPATTY_SIZE 280
#define COOKEDPATTY_LENGTH 140
#define COOKEDPATTY_WIDTH 20
#define COOKEDPATTY_HEIGHT 7

#endif

