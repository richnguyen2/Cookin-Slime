/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 highScoreScreen highScoreScreen.png 
 * Time-stamp: Monday 07/17/2023, 17:55:31
 * 
 * Image Information
 * -----------------
 * highScoreScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HIGHSCORESCREEN_H
#define HIGHSCORESCREEN_H

extern const unsigned short highScoreScreen[38400];
#define HIGHSCORESCREEN_SIZE 76800
#define HIGHSCORESCREEN_LENGTH 38400
#define HIGHSCORESCREEN_WIDTH 240
#define HIGHSCORESCREEN_HEIGHT 160

#endif

