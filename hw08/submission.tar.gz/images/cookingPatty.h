/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x13 cookingPatty cookingPatty.png 
 * Time-stamp: Saturday 07/15/2023, 23:55:48
 * 
 * Image Information
 * -----------------
 * cookingPatty.png 20@13
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef COOKINGPATTY_H
#define COOKINGPATTY_H

extern const unsigned short cookingPatty[260];
#define COOKINGPATTY_SIZE 520
#define COOKINGPATTY_LENGTH 260
#define COOKINGPATTY_WIDTH 20
#define COOKINGPATTY_HEIGHT 13

#endif

