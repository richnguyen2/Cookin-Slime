/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x7 buncheese buncheese.png 
 * Time-stamp: Sunday 07/16/2023, 05:37:45
 * 
 * Image Information
 * -----------------
 * buncheese.png 20@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BUNCHEESE_H
#define BUNCHEESE_H

extern const unsigned short buncheese[140];
#define BUNCHEESE_SIZE 280
#define BUNCHEESE_LENGTH 140
#define BUNCHEESE_WIDTH 20
#define BUNCHEESE_HEIGHT 7

#endif

