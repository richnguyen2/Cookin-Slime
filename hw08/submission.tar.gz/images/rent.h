/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 rent rent.png 
 * Time-stamp: Monday 07/17/2023, 07:03:05
 * 
 * Image Information
 * -----------------
 * rent.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RENT_H
#define RENT_H

extern const unsigned short rent[38400];
#define RENT_SIZE 76800
#define RENT_LENGTH 38400
#define RENT_WIDTH 240
#define RENT_HEIGHT 160

#endif

