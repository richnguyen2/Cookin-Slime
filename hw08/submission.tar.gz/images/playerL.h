/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 playerL playerL.png 
 * Time-stamp: Friday 07/14/2023, 01:49:26
 * 
 * Image Information
 * -----------------
 * playerL.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYERL_H
#define PLAYERL_H

extern const unsigned short playerL[400];
#define PLAYERL_SIZE 800
#define PLAYERL_LENGTH 400
#define PLAYERL_WIDTH 20
#define PLAYERL_HEIGHT 20

#endif

