/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x7 steak steak.png 
 * Time-stamp: Friday 07/14/2023, 19:56:38
 * 
 * Image Information
 * -----------------
 * steak.png 20@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STEAK_H
#define STEAK_H

extern const unsigned short steak[140];
#define STEAK_SIZE 280
#define STEAK_LENGTH 140
#define STEAK_WIDTH 20
#define STEAK_HEIGHT 7

#endif

