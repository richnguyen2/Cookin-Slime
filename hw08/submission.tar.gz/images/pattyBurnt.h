/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x13 pattyBurnt pattyBurnt.png 
 * Time-stamp: Sunday 07/16/2023, 01:37:34
 * 
 * Image Information
 * -----------------
 * pattyBurnt.png 20@13
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PATTYBURNT_H
#define PATTYBURNT_H

extern const unsigned short pattyBurnt[260];
#define PATTYBURNT_SIZE 520
#define PATTYBURNT_LENGTH 260
#define PATTYBURNT_WIDTH 20
#define PATTYBURNT_HEIGHT 13

#endif

