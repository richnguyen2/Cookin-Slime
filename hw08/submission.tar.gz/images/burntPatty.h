/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x7 burntPatty burntPatty.png 
 * Time-stamp: Sunday 07/16/2023, 01:49:16
 * 
 * Image Information
 * -----------------
 * burntPatty.png 20@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BURNTPATTY_H
#define BURNTPATTY_H

extern const unsigned short burntPatty[140];
#define BURNTPATTY_SIZE 280
#define BURNTPATTY_LENGTH 140
#define BURNTPATTY_WIDTH 20
#define BURNTPATTY_HEIGHT 7

#endif

