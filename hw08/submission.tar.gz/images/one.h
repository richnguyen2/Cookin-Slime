/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 one one.png 
 * Time-stamp: Sunday 07/16/2023, 21:28:28
 * 
 * Image Information
 * -----------------
 * one.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ONE_H
#define ONE_H

extern const unsigned short one[35];
#define ONE_SIZE 70
#define ONE_LENGTH 35
#define ONE_WIDTH 5
#define ONE_HEIGHT 7

#endif

