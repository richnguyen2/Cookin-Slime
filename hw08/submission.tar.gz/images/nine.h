/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 nine nine.png 
 * Time-stamp: Sunday 07/16/2023, 21:11:14
 * 
 * Image Information
 * -----------------
 * nine.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NINE_H
#define NINE_H

extern const unsigned short nine[35];
#define NINE_SIZE 70
#define NINE_LENGTH 35
#define NINE_WIDTH 5
#define NINE_HEIGHT 7

#endif

