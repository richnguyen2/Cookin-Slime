/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 loser loser.png 
 * Time-stamp: Monday 07/17/2023, 17:01:48
 * 
 * Image Information
 * -----------------
 * loser.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSER_H
#define LOSER_H

extern const unsigned short loser[38400];
#define LOSER_SIZE 76800
#define LOSER_LENGTH 38400
#define LOSER_WIDTH 240
#define LOSER_HEIGHT 160

#endif

