/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=12x8 slimey slimey.png 
 * Time-stamp: Monday 07/17/2023, 22:02:41
 * 
 * Image Information
 * -----------------
 * slimey.png 12@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SLIMEY_H
#define SLIMEY_H

extern const unsigned short slimey[96];
#define SLIMEY_SIZE 192
#define SLIMEY_LENGTH 96
#define SLIMEY_WIDTH 12
#define SLIMEY_HEIGHT 8

#endif

