/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 eight eight.png 
 * Time-stamp: Sunday 07/16/2023, 21:37:38
 * 
 * Image Information
 * -----------------
 * eight.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EIGHT_H
#define EIGHT_H

extern const unsigned short eight[35];
#define EIGHT_SIZE 70
#define EIGHT_LENGTH 35
#define EIGHT_WIDTH 5
#define EIGHT_HEIGHT 7

#endif

