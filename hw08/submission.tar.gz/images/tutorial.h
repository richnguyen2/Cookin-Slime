/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 tutorial tutorial.png 
 * Time-stamp: Monday 07/17/2023, 22:29:00
 * 
 * Image Information
 * -----------------
 * tutorial.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TUTORIAL_H
#define TUTORIAL_H

extern const unsigned short tutorial[38400];
#define TUTORIAL_SIZE 76800
#define TUTORIAL_LENGTH 38400
#define TUTORIAL_WIDTH 240
#define TUTORIAL_HEIGHT 160

#endif

