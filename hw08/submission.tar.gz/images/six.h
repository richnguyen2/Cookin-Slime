/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 six six.png 
 * Time-stamp: Sunday 07/16/2023, 21:10:47
 * 
 * Image Information
 * -----------------
 * six.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SIX_H
#define SIX_H

extern const unsigned short six[35];
#define SIX_SIZE 70
#define SIX_LENGTH 35
#define SIX_WIDTH 5
#define SIX_HEIGHT 7

#endif

