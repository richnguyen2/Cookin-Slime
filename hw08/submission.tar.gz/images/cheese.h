/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x7 cheese cheese.png 
 * Time-stamp: Friday 07/14/2023, 17:42:11
 * 
 * Image Information
 * -----------------
 * cheese.png 20@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHEESE_H
#define CHEESE_H

extern const unsigned short cheese[140];
#define CHEESE_SIZE 280
#define CHEESE_LENGTH 140
#define CHEESE_WIDTH 20
#define CHEESE_HEIGHT 7

#endif

