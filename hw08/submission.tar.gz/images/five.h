/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 five five.png 
 * Time-stamp: Sunday 07/16/2023, 21:10:42
 * 
 * Image Information
 * -----------------
 * five.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIVE_H
#define FIVE_H

extern const unsigned short five[35];
#define FIVE_SIZE 70
#define FIVE_LENGTH 35
#define FIVE_WIDTH 5
#define FIVE_HEIGHT 7

#endif

