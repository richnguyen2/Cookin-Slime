/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x8 cheeseburger cheeseburger.png 
 * Time-stamp: Sunday 07/16/2023, 02:35:04
 * 
 * Image Information
 * -----------------
 * cheeseburger.png 20@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHEESEBURGER_H
#define CHEESEBURGER_H

extern const unsigned short cheeseburger[160];
#define CHEESEBURGER_SIZE 320
#define CHEESEBURGER_LENGTH 160
#define CHEESEBURGER_WIDTH 20
#define CHEESEBURGER_HEIGHT 8

#endif

