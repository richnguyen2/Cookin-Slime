/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 zero zero.png 
 * Time-stamp: Sunday 07/16/2023, 20:48:02
 * 
 * Image Information
 * -----------------
 * zero.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ZERO_H
#define ZERO_H

extern const unsigned short zero[35];
#define ZERO_SIZE 70
#define ZERO_LENGTH 35
#define ZERO_WIDTH 5
#define ZERO_HEIGHT 7

#endif

