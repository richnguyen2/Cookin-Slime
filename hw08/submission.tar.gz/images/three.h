/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x7 three three.png 
 * Time-stamp: Sunday 07/16/2023, 21:10:30
 * 
 * Image Information
 * -----------------
 * three.png 5@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef THREE_H
#define THREE_H

extern const unsigned short three[35];
#define THREE_SIZE 70
#define THREE_LENGTH 35
#define THREE_WIDTH 5
#define THREE_HEIGHT 7

#endif

